<?php if(session()->has('email')): ?>


<?php $__env->startSection('title', '| myprofile'); ?>
<?php $__env->startSection('stylesheet'); ?>
<!-- <link rel="stylesheet" href="css/bootstrap.css"> -->
<!-- <link rel="stylesheet" href="js/bootstrap.min.js"> -->
<!-- <link rel="stylesheet" href="profile/profile.css"> -->
<!-- <link rel="stylesheet" href="needy/css/side.css"> -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- Adding oh-autoVal script file -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<!------ Include the above in your HEAD tag ---------->


<!------ Include the above in your HEAD tag ---------->

<body style="background-image: url(needya/images/temp/slide-2.jpg);">
    <div id="content">
        <div class="container " style="width:60%;margin-top:-10%;background-color:#91A19F;border-radius: 10px">
            <div class=" card-container col-12">


                <div class="row">
                    <div class="right">
                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(Session::get('message')); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-10">
                        <h1></h1>
                    </div>
                </div>
                <?php if(isset($users)): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form class="form" action="/needyupdateprofile" method="post" id="registrationForm"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-3">
                            <!--left col-->
                            <div class="text-center">
                                <img id="image" src="/uploads/needyprofile/<?php echo e($user->image); ?>"
                                    class="avatar img-circle img-thumbnail" alt="avatar">
                                <h6>Upload a different photo...</h6>
                                <input type="file" name="file" id="file" class="text-center file-upload"
                                    style="width:90%;margin-left:2%;" onchange="readURL(this);">

                            </div>
                            <div class="col-xs-4 pt-4" style="margin-top:3%;">
                                <input type="submit" class="btn btn-success" id="updateimage" name="updateimage"
                                    value="updateimage">

                            </div>
                            </hr><br>
                        </div>
                        <!--/col-3-->
                        <div class="col-sm-9">
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#home">Profile</a></li>

                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane active" id="home">
                                    <hr>

                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="first_name">
                                                <h6>Name</h6>
                                            </label>
                                            <input type="text" name="name" id="name" value="<?php echo e($user->name); ?>"
                                                class="form-control " title="enter your first name if any." readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="email">
                                                <h6>Email</h6>
                                            </label>
                                            <input type="email" class="form-control" name="email" id="email"
                                                value="<?php echo e($user->email); ?>" title="enter your email." readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="phone">
                                                <h6>Phone</h6>
                                            </label>
                                            <input type="text" class="form-control" name="phone" id="phone"
                                                value="<?php echo e($user->phonenumber); ?>" title="enter your phone number if any."
                                                readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="last_name">
                                                <h6>Address line 1</h6>
                                            </label>
                                            <input type="text" class=" form-control" name="add1" id="add1"
                                                value="<?php echo e($user->addressline1); ?>" title="enter your last name if any."
                                                readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="last_name">
                                                <h6>Address line 2</h6>
                                            </label>
                                            <input type="text" class="form-control" name="add2" id="add2"
                                                value="<?php echo e($user->addressline2); ?>" title="enter your last name if any."
                                                readonly>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="last_name">
                                                <h6>State</h6>
                                            </label>


                                            <script src="admin/js/jquery-3.3.1.js"></script>
                                            <script src="js/state.js"> </script>

                                            <select name="state" id="state" class="form-control" disabled>
                                                <option disabled selected value> <?php echo e($user->sname); ?></option>
                                                <?php if(isset($state)): ?>
                                                <?php $__currentLoopData = $state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $states): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($states->state_id); ?>"><?php echo e($states->sname); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                            </select>
                                        </div>

                                    </div>

                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="last_name">
                                                <h6>District</h6>
                                            </label>

                                            <select name="district" id="district" class=" form-control input" disabled>
                                                <option disabled selected value=""> <?php echo e($user->dname); ?> </option>
                                            </select>

                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="last_name">
                                                <h6>Panchayath</h6>
                                            </label>
                                            <select name="panchayath" id="panchayath" class=" form-control" readOnly>
                                                <option selected value="<?php echo e($user->panchayath_id); ?>"> <?php echo e($user->pname); ?>

                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="password">
                                                <h6>Pincode</h6>
                                            </label>
                                            <input type="number" class=" form-control " name="pincode" id="pincode"
                                                value="<?php echo e($user->pincode); ?>" title="." readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-xs-6">
                                            <label for="last_name">
                                                <h6>Category</h6>
                                            </label>

                                            <select name="catnam" id="catnam" class="form-control" readOnly>
                                                <option disabled selected value> <?php echo e($user->catname); ?> </option>


                                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($categorya->category_id); ?>"><?php echo e($categorya->categoryname); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            </select>
                                        </div>

                                    </div>

                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="password">
                                                <h6></h6>
                                            </label>
                                            <input type="hidden" class=" form-control " title="." readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="password">
                                                <h6></h6>
                                            </label>
                                            <input type="hidden" class=" form-control " title="." readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="password">
                                                <h6></h6>
                                            </label>
                                            <input type="hidden" class=" form-control " title="." readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">

                                        <div class="col-xs-6">
                                            <label for="password">
                                                <h6></h6>
                                            </label>
                                            <input type="hidden" class=" form-control " title="." readonly>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">

                                            

                                            <div class="col-xs-4 pl-4 mt-10">
                                                <input class="btn btn-lg btn-success" id="edit" type="button"
                                                    name="edit" value="Edit">
                                            </div>
                                            <div class="col-xs-4 pl-4">
                                                <input type="submit" class="btn btn-lg btn-success" id="update"
                                                    style="display: none;" value="update">

                                            </div>
                                            
                                            
                                        </div>

                                    </div>



                                    <hr>

                                </div>
                                <!--/tab-pane-->



                            </div>
                            <!--/tab-content-->

                        </div>
                        <!--/col-9-->
                    </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <!--/row-->
            </div>

        </div>
    </div>
</body>


<script src="needy/js/profile.js"></script>
<script src="regvalidation/js/jquery.validate.js"> </script>
<script src="regvalidation/js/additional-methods.js"> </script>
<script src="regvalidation/js/valid.js"></script>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php 
    return redirect('/loginn');

?>
<?php endif; ?>
<?php echo $__env->make('layouts.needymenubar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>