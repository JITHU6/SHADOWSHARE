<?php if(session()->has('email')): ?>


<?php $__env->startSection('title', '| fundrequeststory'); ?>



<?php $__env->startSection('stylesheet'); ?>




<link rel="stylesheet" href="needy/css/question.css">
<link rel="stylesheet" href="needy/css/storyprofile.css">
<link rel="stylesheet" href="profile/effect.css">

<?php $__env->stopSection(); ?>
<style>
input.error {
    background: white;
    color: rgb(10, 10, 10);
}



label.error {
    color: white;
    background-color: #db4437;

    padding: 10px 20px;
    border-radius: 4px;
    font-family: 'Courier New', Courier, monospace;
}

.zoom {


    transition: transform .2s;
    /* Animation */

    margin: 0 auto;
}

.zoom:hover {
    transform: scale(2.2);
    /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
</style>
<?php $__env->startSection('sidemenu'); ?>

<body class="">
    <div class="container">
        <div class="col-12 " id="myDIV" style="background-color: #00735D;margin-top:10%;">

            <form action="/saveeqstory" method="POST" class="form-signin " id="msform" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>


                <div class="card-header" style="margin-top:20%;background:#00365C;">
                    <label class="card-title">
                        <h4 style="color:white;">
                            Equipment Case Story</h4>
                    </label>
                </div>
                <div class="right">
                    <?php if(Session::has('message')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(Session::get('message')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="row">


                    <div class="col-md-8" style="margin-left:18%;margin-top:10%;">
                        <!-- ? script to dispalya question -->
                        <!-- <script src="admin/js/question.js"></script> -->

                        <div class=" form-group" style="Color:#ffff;width:87%;"><label>Equipment Category</label>
                            <select id="option" name="cataaa" class="form-control default-select">
                                <?php if(isset($data)): ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->categoryname); ?></option>
                                <input type="hidden" id="inputEmail" name="cat" class="form-control"
                                    value="<?php echo e($category->category_id); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </select>

                        </div>
                    </div>
                </div>
                <?php if(isset($user)): ?>
                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class=" row">

                    <div class="card card-container col-md-7" style="margin-left:20%; ">
                        <div>
                            <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
                            <!-- <img id="profile-img" class="profile-img-card" src="//ssl.gstatic.com/accounts/ui/avatar_2x.png" /> -->
                            <div class="pt-3">
                                <label>Personal Details</label>
                            </div>
                            <div class="col-md-7" style="left:25%;">

                                <img id="image" class="profile-img-card large thumbnail"
                                    src="/uploads/needyprofile/<?php echo e($users->image); ?>" />
                            </div>

                            <div class="pt-3">
                                <input type="email" id="inputEmail" class="form-control" placeholder="Email address"
                                    value="<?php echo e($users->email); ?>" required autofocus readonly>
                            </div>
                            <div class="pt-3">
                                <input type="email" id="inputEmail" class="form-control" placeholder="Email address"
                                    value="<?php echo e($users->name); ?>" required autofocus readonly>
                            </div>
                            <div class="pt-3">
                                <input type="email" id="inputEmail" class="form-control" placeholder="Email address"
                                    value="<?php echo e($users->phonenumber); ?>" required autofocus readonly>
                            </div>
                            <div class="pt-3">
                                <input type="email" id="inputEmail" class="form-control" placeholder="Email address"
                                    value="<?php echo e($users->pname); ?>" required autofocus readonly>
                            </div>


                            
                            <!-- /form -->


                        </div>
                    </div>

                </div>

                <div id="accordion">

                    <div class="card">
                        <div class="card-header">
                            <a class="card-link " data-toggle="collapse" href="#collapseOne">
                                <h5>
                                    Provide another address to
                                    verify.
                                    you</h5>
                            </a>
                        </div>
                        <div id="collapseOne" class="collapse show" data-parent="#accordion">
                            <div class="card-body">
                                <div class="pt-3">
                                    <textarea class="form-control" name="vaddress" id="" rows=" 6"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="accordion">

                    <div class="card">
                        <div class="card-header">
                            <a class="card-link " data-toggle="collapse" href="#collapse2">
                                <h5>
                                    Upload an identity proof</h5>
                            </a>
                        </div>
                        <div id="collapse2" class="collapse show" data-parent="#accordion">
                            <div class="card-body">
                                <div class="pt-3">
                                    <?php if($users->verification_document): ?>
                                    <div class="zoom">
                                        <img id="imaa" src="uploads/verify/<?php echo e($users->verification_document); ?>"
                                            class="avatar img-circle img-thumbnail ima" style="width:200;height:200;"
                                            alt="avatar">
                                    </div>
                                    <button id="changefile">
                                        <h6>Upload a different photo...</h6>
                                    </button>
                                    <input type="file" name="casefile" id="filea" class="text-center file-upload"
                                        style="width:70%;display:none;" onchange="loadFile2(event)">

                                    <?php else: ?>
                                    <div class="zoom">
                                        <img id="ima" src="" class="avatar img-circle img-thumbnail ima"
                                            style="width:200;height:200;" alt="avatar">
                                    </div>
                                    <h6>Upload a different photo...</h6>
                                    <input type="file" name="casefile" id="file" class="text-center file-upload"
                                        style="width:70%;" onchange="loadFile1(event)">

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div id="accordion">

                    <div class="card">
                        <div class="card-header">
                            <a class="card-link " data-toggle="collapse" href="#collapse3">
                                <h5>
                                    Selected
                                    Equipment</h5>
                            </a>
                        </div>
                        <div id="collapse3" class="collapse show" data-parent="#accordion">
                            <div class="card-body">
                                <div class="pt-3">
                                    <select id="eq" name="equipmentaa" class="form-control default-select">
                                        <?php if(isset($equipment)): ?>
                                        <?php $__currentLoopData = $equipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($eq->equipment_id); ?>"><?php echo e($eq->cname); ?></option>
                                        <input type="hidden" id="inputEmail" name="equipment" class="form-control"
                                            value="<?php echo e($eq->equipment_id); ?>">
                                        <input type="hidden" id="inputEmail" name="ename" class="form-control"
                                            value="<?php echo e($eq->name); ?>">
                                        <input type="hidden" id="inputEmail" name="eemail" class="form-control"
                                            value="<?php echo e($eq->email); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </select>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>




                <div id="accordion">

                    <div class="card">
                        <div class="card-header">
                            <a class="card-link " data-toggle="collapse" href="#collapse4">
                                <h5>
                                    Provide Case Titile</h5>
                            </a>
                        </div>
                        <div id="collapse4" class="collapse show" data-parent="#accordion">
                            <div class="card-body">
                                <div class="pt-3">
                                    <input type="text" id="inputEmail" name="casetitle" class="form-control"
                                        placeholder="enter case title" autofocus>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="accordion">

                    <div class="card">
                        <div class="card-header">
                            <a class="card-link " data-toggle="collapse" href="#collapse5">
                                <h5>
                                    Upload Case Image</h5>
                            </a>
                        </div>
                        <div id="collapse5" class="collapse show" data-parent="#accordion">
                            <div class="card-body">
                                <div class="pt-3">
                                    <img id="im" class="avatar img-thumbnail" alt="avatar">
                                    <h6>Upload a different photo...</h6>
                                    <input type="file" name="file" id="file" class="text-center file-upload"
                                        style="width:70%;" onchange="loadFile(event)" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="accordion">

                    <div class="card">
                        <div class="card-header">
                            <a class="card-link " data-toggle="collapse" href="#collapseOne">
                                <h5>
                                    Describe you current situation.
                                </h5>
                            </a>
                        </div>
                        <div id="collapseOne" class="collapse show" data-parent="#accordion">
                            <div class="card-body">
                                <div class="pt-3">
                                    <textarea class="form-control" name="edescription" id="" rows="6"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="">

                    <!-- <div class="card-header">
                        <label class="card-link " data-toggle="collapse" href="#collapse5">
                            <h5 style="color:white;">Attend the questions to make case
                                story <br>(select category from the category list)</h5>
                        </label>
                    </div> -->
                    <!-- <div class="col-md-12">


                        <div class="tab" id="">

                            <div id="count1">

                            </div>




                        </div>
                    </div> -->





                    <!-- <div class="input-group-icon mt-10">




                        

                    <!-- progressbar -->
                    <!-- <ul id="progressbar">


                    </ul> -->
                    <!-- fieldsets -->
                    <!-- <div style="margin-left:8%;margin-bottom:20%;">
                        <fieldset>
                            <div style="color:rgb(90, 167, 150);">
                                <?php echo e($a=1); ?>

                            </div>
                            <?php if(isset($question)): ?>
                            <?php $__currentLoopData = $question; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php if($aa->option_a == null && $aa->option_b == null && $aa->option_c == null &&
                            $aa->option_d == null): ?>
                            <h2 class=" fs-title">Question <?php echo e($a); ?></h2>

                            <h3 class="fs-subtitle"><?php echo e($aa->question); ?></h3><input type="hidden" name="question<?php echo e($a); ?>"
                                value="<?php echo e($aa->question_id); ?>" <br>
                            <label>
                            </label></br><textarea class="form-control" name="answer<?php echo e($a); ?>" id=" CAT_Custom_7" rows="4"
                                onkeydown='if(this.value.length>=4000)this.value=this.value.substring(0,3999);'
                                required></textarea>
                            <?php endif; ?>
                            <?php if($aa->option_a && $aa->option_b && $aa->option_c && $aa->option_d): ?>
                            <h2 class=" fs-title">Question<?php echo e($a); ?> </h2>
                            <h3 class="fs-subtitle"><?php echo e($aa->question); ?></h3>
                            <input type="hidden" name="question<?php echo e($a); ?>" value=" <?php echo e($aa->question_id); ?>"> <br>
                            <label>Choose
                                Option </label></br><select id="op1" class="form-control" name="answer<?php echo e($a); ?>" required>
                                <option value="<?php echo e($aa->option_a); ?>"><?php echo e($aa->option_a); ?></option>
                                <option value="<?php echo e($aa->option_b); ?>"><?php echo e($aa->option_b); ?></option>
                                <option value="<?php echo e($aa->option_c); ?>"><?php echo e($aa->option_c); ?></option>
                                <option value="<?php echo e($aa->option_d); ?>"><?php echo e($aa->option_d); ?></option>
                            </select></br>

                            <?php endif; ?>
                            <div style="color:rgb(90, 167, 150);">
                                <?php echo e($a++); ?>




                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <input type="hidden" name="count" value="<?php echo e($a); ?>">

                                <input type="submit" name="submit" class="genric-btn success-border medium"
                                    value="submit" />

                        </fieldset>

                    </div> -->

                    <!-- jQuery -->

                    <!-- jQuery easing plugin -->
                    <!-- <script src=" https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"
                        type="text/javascript"></script>



                    <script src="needy/js/question.js"></script>



                </div> -->


                    <input type="submit" name="submit" class="genric-btn success-border medium" value="submit" />
            </form>
        </div>

    </div>
    </div>
</body>
<script src="admin/js/jquery-3.3.1.js"> </script>
<script src="regvalidation/js/jquery.validate.js"> </script>
<script src="regvalidation/js/additional-methods.js"> </script>
<script src="needy/js/fstoryvalid.js"></script>
<!-- <script src="needy/js/fstory.js"></script> -->

<script>
var loadFile = function(event) {
    var reader = new FileReader();
    reader.onload = function() {
        var output = document.getElementById('im');
        output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
};
var loadFile1 = function(event) {
    var reader = new FileReader();
    reader.onload = function() {
        var output = document.getElementById('ima');
        output.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
};
var el9 = document.getElementById('changefile');

el9.onclick = function() {

    document.getElementById("filea").style.display = "block";
    //document.getElementById("reset").style.display = "block";
};
</script>

<?php $__env->stopSection(); ?>

<?php else: ?>
<?php 
    return redirect('/loginn');

?>
<?php endif; ?>
<?php echo $__env->make('needy.index', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>