<?php if(session()->has('sponsor')): ?>

<?php $__env->startSection('content'); ?>

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="profile/effect.css">


</head>
<div id="record">
    <div class=" col-md-12 card" style="margin-top:-7%;">
        <h5 class="project-title" itemprop="name">
            Fund Donated Deatails</h5>
    </div>
    <div class="left">
        <?php if(Session::has('message')): ?>
        <script>
        alert("<?php echo e(Session::get('message')); ?>");
        </script>
        <?php endif; ?>
    </div>
    <section class="section">
        <div class="container">

            <div class="card mb-3">
                <div class="card-header">
                    <i class="fas fa-table"></i>
                    Donated List</div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Sl.No</th>
                                    <th>Beneficiry Name</th>
                                    <th>Beneficiry's Mobile</th>
                                    <th>Amount(Rs)/Equipment</th>
                                    <th>Date </th>
                                    <!-- <th>Details</th> -->

                                </tr>
                            </thead>
                            <tfoot>
                                <tr>


                                </tr>
                            </tfoot>
                            <tbody>
                                <?php if(isset($data)): ?>
                                <input type="hidden" value=" <?php echo e($count=1); ?> ">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if(isset($a->names)): ?>
                                <tr>
                                    <td><?php echo e($count); ?></td>
                                    <td><?php echo e($a->names); ?></td>
                                    <td><?php echo e($a->phone); ?></td>
                                    <td><?php echo e($a->amount); ?></td>
                                    <td><?php echo e(date("Y-m-d", strtotime($a->updated_at))); ?></td>
                                    <!-- <td class="align-content-center">

                                                    <button type="button" class="btn btn-danger btn-block"
                                                        data-toggle="modal" data-target="#myModal" id="equip###"
                                                        onclick="morea('<?php echo e($a->case_id); ?>')">
                                                        More Deatails
                                                    </button>

                                                </td> -->



                                </tr>

                                <?php endif; ?>



                                <input type="hidden" value=" <?php echo e($count++); ?> ">

                                <!-- The Modal -->

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <button type="submit" style="margin-top:5%;color:white;background:gray;"
                    class="btn btn-success-outline pull-right" onclick="createPDF()">Download</button>
                <div class=" card-footer small text-muted">
                </div>
            </div>
        </div>

    </section>


</div>
<script src="sponsor/casedetails.js">
</script>
<script src="js/state.js"> </script>
<script>
function createPDF() {
    var sTable = document.getElementById('record').innerHTML;

    var style = "<style>";
    style = style + "table {width: 100%;font: 17px Calibri;}";
    style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
    style = style + "padding: 2px 3px;text-align: center;}";
    style = style + "</style>";

    // CREATE A WINDOW OBJECT.
    var win = window.open('', '', 'height=700,width=700');

    win.document.write('<html><head>');
    win.document.write('<title>Ticket Details</title>'); // <title> FOR PDF HEADER.
    win.document.write(style); // ADD STYLE INSIDE THE HEAD TAG.
    win.document.write('</head>');
    win.document.write('<body>');
    win.document.write(sTable); // THE TABLE CONTENTS INSIDE THE BODY TAG.
    win.document.write('</body></html>');

    win.document.close(); // CLOSE THE CURRENT WINDOW.

    win.print(); // PRINT THE CONTENTS.

}
</script>
<?php $__env->stopSection(); ?>
<?php else: ?>
<?php
return redirect('/loginn');

?>
<?php endif; ?>
<?php echo $__env->make('layouts.sponsormenubar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>