<?php if(session()->has('status2')): ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="admin/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="admin/css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.css">

</head>

<body id="page-top">

    <?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="wrapper">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="content-wrapper">
            <div class="container-fluid">
                <form class="form-inline pl-5" style="margin-top:10%;" action="/addcat" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-2 ">


                        <input type="text" readonly class="form-control-plaintext" id="staticEmail2"
                            value="Category Name">
                    </div>
                    <div class="form-group mx-sm-3 mb-2">

                        <input type="text" class="form-control" id="inputPassword2" placeholder="" name="cname"
                            pattern="[a-zA-Z][a-zA-Z ]+[a-zA-Z]$" style="text-transform:capitalize;"
                            title=" enter valid category name" required>
                    </div>
                    <button type=" submit" class="btn btn-primary mb-2">Add Category</button>
                </form>


                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fas fa-table"></i>
                        Category List</div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="80%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Sl.No</th>
                                        <th>Category Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>


                                    </tr>
                                </tfoot>
                                <tbody>
                                    <?php if(isset($data)): ?>
                                    <input type="hidden" value="<?php echo e($count=1); ?>">

                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <tr>
                                        <td><?php echo e($count); ?></td>
                                        <td><?php echo e($user->categoryname); ?></td>
                                        <td class="align-content-center">

                                            <a class="btn btn-outline-primary ml-3"
                                                href="<?php echo e(url('deletecategory/'.$user->category_id)); ?>">Delete</a>
                                            <?php if($user->status == 1): ?>
                                            <a class="btn btn-outline-primary ml-3"
                                                href="<?php echo e(url('updatecategory/'.$user->category_id)); ?>">Block</a> </td>
                                        <?php else: ?>
                                        <a class="btn btn-outline-primary ml-3"
                                            href="<?php echo e(url('updatecategory/'.$user->category_id)); ?>">UnBlock</a> </td>
                                        <?php endif; ?>
                                    </tr>

                                    <input type="hidden" value="<?php echo e($count=$count+1); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>


                                </tbody>
                            </table>

                        </div>
                    </div>
                    <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                </div>


            </div>

        </div>
    </div>


    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script src="admin/js/jquery-3.3.1.min.js"> </script>

    <?php else: ?>
    <?php 
    return redirect('/loginn');

?>
    <?php endif; ?>