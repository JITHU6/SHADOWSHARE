@extends('layouts.menubar')
@section('cont')

<!--================ End Home Banner Area =================-->

<!--================ Start Recent Event Area =================-->
<section class="">
    <div class="container">
        <div class="row align-items-center justify-content-center" style="margin-top:10%;">
            <div class="col-lg-6 col-md-8 col-sm-10">
                <div class="condition-left">
                    <img class="img-fluid" src="img/event/event-details.jpg" alt="">
                </div>
            </div>
            <div class="offset-lg-1 col-lg-5">
                <div class="condition-right">
                    <h2 class="mb-20">
                        What We do
                    </h2>
                    <ol class="list-group-flush" type="1">
                        <li class="list-group-item">We try to bring togther needy and the donornto a single plateform.
                        </li>
                        <li class="list-group-item">We provide less risk donation system</li>
                        <li class="list-group-item">We allow sponsors to donate equipments and fund </li>
                        <li class="list-group-item">We provide support for any assistance</li>
                    </ol>

                    <p>

                    </p>
                    <!-- <ul>
                        <li>Saturday, 15th September, 2018</li>
                        <li>Rocky beach Church</li>
                        <li>Los Angeles, USA.</li>
                    </ul> -->
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End Recent Event Area =================-->
@endsection