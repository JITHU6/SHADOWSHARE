<?php if(session()->has('status2')): ?>
<!-- Sidebar -->


<ul class="sidebar navbar-nav">
    <li class="nav-item active">
        <a class="nav-link" href="/adminindex">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Home</span>
        </a>
    </li>
    
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>View users</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">#</h6>
            <a class="dropdown-item" href="/userneedy">Needy</a>
            <a class="dropdown-item" href="/userfunddonor">Sponser</a>
            <a class="dropdown-item" href="/userequipment">Equipment Donor</a>
            <!-- <a class=" dropdown-item" href="forgot-password.html">Forgot Password</a>
            <div class="dropdown-divider"></div>
            <h6 class="dropdown-header">Other Pages:</h6>
            <a class="dropdown-item" href="404.html">404 Page</a>
            <a class="dropdown-item" href="blank.html">Blank Page</a> -->
        </div>
    </li>
    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>View Transactions</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">#</h6>
            <a class="dropdown-item" href="/adminviewneedy">Needy</a>
            <a class="dropdown-item" href="/viewefunddonor">Sponsor</a>
            <a class="dropdown-item" href="/viewequipdonor">Equipment Donor</a>
            <!-- <a class="dropdown-item" href="forgot-password.html">Forgot Password</a>
                <div class="dropdown-divider"></div>
                <h6 class="dropdown-header">Other Pages:</h6>
                <a class="dropdown-item" href="404.html">404 Page</a>
                <a class="dropdown-item" href="blank.html">Blank Page</a> -->
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link" href="/addcategory">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Add Category</span></a>
    </li>

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>Questions</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">#</h6>
            <a class="dropdown-item" href="/addquestion">Add Questions</a>
            <a class="dropdown-item" href="/listquestion">View or Edit Question</a>
            <!-- <a class="dropdown-item" href="forgot-password.html">Forgot Password</a>
                    <div class="dropdown-divider"></div>
                    <h6 class="dropdown-header">Other Pages:</h6>
                    <a class="dropdown-item" href="404.html">404 Page</a>
                    <a class="dropdown-item" href="blank.html">Blank Page</a> -->
        </div>
    </li>
    <li class="nav-item dropdown">

        <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown"
            aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-folder"></i>
            <span>Urgent Fundraising</span>
        </a>
        <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <h6 class="dropdown-header">#</h6>
            <a class="dropdown-item" href="<?php echo e(URL::to('fundraise')); ?>">Add Case Deatailes</a>
            <a class="dropdown-item" href="/viewcase">View or Edit Case</a>
            <!-- <a class="dropdown-item" href="forgot-password.html">Forgot Password</a>
                    <div class="dropdown-divider"></div>
                    <h6 class="dropdown-header">Other Pages:</h6>
                    <a class="dropdown-item" href="404.html">404 Page</a>
                    <a class="dropdown-item" href="blank.html">Blank Page</a> -->
        </div>
    </li>
</ul>

<?php else: ?>
<?php 
        return redirect('/loginn');
    
    ?>
<?php endif; ?>