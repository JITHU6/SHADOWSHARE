<?php if(session()->has('status2')): ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SS Admin - Dashboard</title>
    <script src="admin/js/jquery-3.3.1.min.js"></script>
    <script src="admin/js/question.js"></script>
    <!-- Custom fonts for this template-->
    <link href="admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="admin/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="admin/css/sb-admin.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.css">

</head>

<body id="page-top">

    <?php echo $__env->make('admin.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="wrapper">
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="content-wrapper">
            <div class="container-fluid">
                <div class="row">

                    <div class="col-md-6" style="margin-left: 10%;margin-top: 5%;">
                        <form role="form" action="/listquestion" post="POST">
                            <?php echo csrf_field(); ?>
                            <div class="">
                                <label class="h3">Update Questions</label>
                            </div>
                            <div class="right">
                                <?php if(Session::has('message')): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="mt-1">
                                    <select class="form-control" id="productSelect" name="category" required>

                                        <option>Select Category</option>
                                        <?php if(isset($data)): ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->category_id); ?>"><?php echo e($category->categoryname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="ml-4">
                                    <button type="submit" id="loginSubmit" class="btn btn-success loginFormElement "
                                        style="margin-top:5%;">submit</button>
                                </div>
                            </div>


                    </div>
                    </form>


                </div>

                <div class="card mb-3 mt-4">
                    <div class="card-header">
                        <i class="fas fa-table"></i>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('flash_message')): ?>
                        <div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> <?php echo session('flash_message'); ?></em></div>
                        <?php endif; ?>
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <button type="submit" style="margin-top:0%;color:blue;;margin-left:90%;"
                            class="btn btn-success-outline right" onclick="createPDF()">Download</button>
                        <div class="table-responsive" id="record">
                            <table class="table table-bordered" id="dataTable" width="80%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Sl.No</th>
                                        <th>Question</th>
                                        <th>Option1</th>
                                        <th>Option2</th>
                                        <th>Option3</th>
                                        <th>Option4</th>
                                        <th>Edit</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>


                                    </tr>
                                </tfoot>
                                <tbody>

                                    <?php if(isset($quest)): ?>

                                    <input type="hidden" value="<?php echo e($count=1); ?>">
                                    <?php $__currentLoopData = $quest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                    <tr id="row<?php echo e($user->question_id); ?>">
                                        <td><?php echo e($count); ?></td>
                                        <td><?php echo e($user->question); ?></td>
                                        <td id="option1<?php echo e($user->question_id); ?>"><?php echo e($user->option_a); ?></td>
                                        <td id="option2<?php echo e($user->question_id); ?>"><?php echo e($user->option_b); ?></td>
                                        <td id="option3<?php echo e($user->question_id); ?>"><?php echo e($user->option_c); ?></td>
                                        <td id="option4<?php echo e($user->question_id); ?>"><?php echo e($user->option_d); ?></td>
                                        <td class="align-content-center">

                                            <input type="button" class="btn btn-outline-primary ml-3" name="edit"
                                                id="edit<?php echo e($user->question_id); ?>" value="Edit"
                                                onclick="edit_row('<?php echo e($user->question_id); ?>')"><br><br>
                                            <input type="button" class="btn btn-outline-primary ml-3" name="save"
                                                id="save<?php echo e($user->question_id); ?>" value="save"
                                                onclick="save_row('<?php echo e($user->question_id); ?>')"><br>
                                            <a class="btn btn-outline-primary ml-3"
                                                href="<?php echo e(url('qdelete/'.$user->question_id)); ?>">Remove</a>

                                        </td>
                                    </tr>
                                    <input type="hidden" value="<?php echo e($count=$count+1); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>


                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer small text-muted">Updated yesterday at 11:59 PM
            </div>
        </div>


        </form>


    </div>

    </div>
    </div>



    <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <script>
    function createPDF() {
        var sTable = document.getElementById('record').innerHTML;

        var style = "<style>";
        style = style + "table {width: 100%;font: 17px Calibri;}";
        style = style + "table, th, td {border: solid 1px #DDD; border-collapse: collapse;";
        style = style + "padding: 2px 3px;text-align: center;}";
        style = style + "</style>";

        // CREATE A WINDOW OBJECT.
        var win = window.open('', '', 'height=700,width=700');

        win.document.write('<html><head>');
        win.document.write('<title>Ticket Details</title>'); // <title> FOR PDF HEADER.
        win.document.write(style); // ADD STYLE INSIDE THE HEAD TAG.
        win.document.write('</head>');
        win.document.write('<body>');
        win.document.write(sTable); // THE TABLE CONTENTS INSIDE THE BODY TAG.
        win.document.write('</body></html>');

        win.document.close(); // CLOSE THE CURRENT WINDOW.

        win.print(); // PRINT THE CONTENTS.

    }
    </script>
    <?php else: ?>
    <?php 
    return redirect('/loginn');

?>
    <?php endif; ?>