
<?php echo $__env->make('seller.sellerheader', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('seller.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javaScript">
    function validate_dropdown(){

         if (document.registrationForm.item_name.value=="")
   {
       alert ("Please enter the item name.");
       document.registrationForm.item_name.value.focus();
       return false;
   }
    if (document.registrationForm.price.value=="")
   {
       alert ("Please enter the item price.");
       document.registrationForm.price.value.focus();
       return false;
   }
   if (document.registrationForm.stock.value=="")
   {
       alert ("Please enter the stock you have.");
       document.registrationForm.stock.value.focus();
       return false;
   }
   if (document.registrationForm.quantity.value=="")
   {
       alert ("Please enter the quantity in the packet/Number of  items in the packet.");
       document.registrationForm.quantity.value.focus();
       return false;
   }


        if (document.registrationForm.category.value=="0")
   {
       alert ("Please select your category.");
       document.registrationForm.category.value.focus();
       return false;
   }

   if (document.registrationForm.subcategory.value=="0")
   {
       alert ("Please select your subcategory.");
       document.registrationForm.subcategory.value.focus();
       return false;
   }

    if (document.registrationForm.discription.value=="")
   {
       alert ("Please provide the description of your product.");
       document.registrationForm.discription.value.focus();
       return false;
   }

   }
   </script>

<div id="wrapper">
         <?php echo $__env->make('seller.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="content-wrapper">
                <div class="container-fluid">
                        <div  class="" >
                                <label class="h3">View Items</label>
                        </div>
                        <div class="card mb-3 mt-4">
                                <div class="card-header">
                                  <i class="fas fa-table"></i>
                                  </div>
                                <div class="card-body">
                                    <?php if(Session::has('flash_message')): ?>
                                    <div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> <?php echo session('flash_message'); ?></em></div>
                                <?php endif; ?>
                                        <?php if(count($errors) > 0): ?>
                                            <div class = "alert alert-danger">
                                                <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                        <div class="table-responsive">
                                            <table class="table table-bordered" id="dataTable" width="80%" cellspacing="0">
                                                <thead>
                                                    <tr>
                                                            <th>Sl.No</th>
                                                            <th>Item Image</th>
                                                            <th>Name</th>
                                                            <th>Description</th>
                                                            <th>Condition</th>
                                                            <th>Pickup Location</th>
                                                            <th>Edit/remove</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        
                                                        
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                        
                                                        <?php if(isset($quest)): ?>

                                                        <?php echo e($count=1); ?>

                                                        <?php $__currentLoopData = $quest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                            
                                                        
                                                    <tr id="row<?php echo e($user->question_id); ?>">
                                                        <td><?php echo e($count); ?></td>
                                                    <td><?php echo e($user->question); ?></td>
                                                        <td id="option1<?php echo e($user->question_id); ?>"><?php echo e($user->option_a); ?></td>
                                                        <td id="option2<?php echo e($user->question_id); ?>"><?php echo e($user->option_b); ?></td>
                                                        <td id="option3<?php echo e($user->question_id); ?>"><?php echo e($user->option_c); ?></td>
                                                        <td id="option4<?php echo e($user->question_id); ?>"><?php echo e($user->option_d); ?></td>
                                                        <td class="align-content-center">
                                                            
                                                            <input type="button" class="genric-btn default-border radius" name="edit" id="edit<?php echo e($user->question_id); ?>"  value="Edit" onclick="edit_row('<?php echo e($user->question_id); ?>')">
                                                           <input type="button" name="save" id="save<?php echo e($user->question_id); ?>"  value="save" onclick="save_row('<?php echo e($user->question_id); ?>')">
                                                              
                                                        </td>
                                                    </tr>
                                                    <?php echo e($count=$count+1); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                            
                                            
                                                </tbody>
                                            </table>

                                        </div>
                                </div>
                                <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
                            </div>

                                </div><!--/tab-content-->
                            
                        </div><!--/col-9-->
                    </div><!--/row-->

                <!-- /.row -->
         
            <!-- /#page-wrapper -->

        
        <!-- /#wrapper -->

        <!-- jQuery -->
        
        
                </div>
        </div>
</div>

<script src="admin/js/profile.js"></script> 
<script src="admin/js/jquery-3.3.1.min.js"></script> 
<script>
    var loadFile = function(event) {
var reader = new FileReader();
reader.onload = function(){
var output = document.getElementById('im');
output.src = reader.result;
};
reader.readAsDataURL(event.target.files[0]);
};
     </script>
<?php echo $__env->make('seller.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
