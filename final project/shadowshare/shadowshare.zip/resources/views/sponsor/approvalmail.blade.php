<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Fund Request Approved Successfully</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <script src="main.js"></script>
</head>

<body>
    <h3>hello {!!$name!!}</h3>
    <p>This is to inform you that requested amount {!!$ename!!} is successfully Approved by Donor.Please confirm the
        same for further procedure.

    </p>
    <p>Team shadowshare</p>
</body>

</html>