<div class="card mb-3">
    <div class="card-header">
        <i class="fas fa-table"></i>
        Category List</div>
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="80%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Category Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>


                    </tr>
                </tfoot>
                <tbody>
                    <!-- @isset($data)

                    {{$count=1}}
                    @foreach ($data as $user) -->


                    <tr>
                        <td>#</td>
                        <td>#</td>
                        <td class="align-content-center">

                            <a class="btn btn-outline-primary ml-3" href="#">Delete</a>
                            <!-- @if($user->status == 1) -->
                            <a class="btn btn-outline-primary ml-3" href="#">Block</a> </td>
                        <!-- @else -->
                        <a class="btn btn-outline-primary ml-3" <!-- href="#">UnBlock</a> </td> -->
                        <!-- @endif -->
                    </tr>SS
                    endloop


                </tbody>
            </table>

        </div>
    </div>
    <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
</div>